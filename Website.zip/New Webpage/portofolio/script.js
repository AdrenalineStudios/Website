// ======================= Typing animation animation ==============================
var typed = new Typed(".typing",{
    strings:["","Web Designer", "Web Developer", "Game Developer", "Full Stack Developer"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})

